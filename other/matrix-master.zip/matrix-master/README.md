### Installation

``` bash
git clone kristjanjansen/matrix
cd matrix
yarn
npm run dev
```
### Production

```bash
npm install -g now
now
```
