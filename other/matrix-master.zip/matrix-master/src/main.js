import Vue from 'vue'
import App from './App.vue'

var events = new Vue()
Vue.prototype.$events = events

new Vue({
  el: '#app',
  render: h => h(App)
})
