<template>

    <svg :width="width" :height="height">
        <circle
            v-for="point in points"
            :cx="xScale(point.x)+1"
            :cy="yScale(point.y)+1"
            r="2"
            :fill="colorMap[point.xKey]"
        />
        <circle
            v-for="point in points"
            :cx="xScale(point.x)-1"
            :cy="yScale(point.y)-1"
            r="2"
            :fill="colorMap[point.yKey]"
        />
        <circle
            v-for="point in points"
            :cx="xScale(point.x)"
            :cy="yScale(point.y)"
            r="10"
            @mouseenter="$events.$emit('point', point)"
            @mouseleave="$events.$emit('point', {x: null, y: null})"
            fill="rgba(0,0,0,0)"
        />
        <line
            :x1="0"
            :y1="height"
            :x2="width"
            :y2="height"
            :stroke="colorMap[points[0].xKey]"
            stroke-width="2"
            opacity="0.5"
        />
        <line
            :x1="0"
            :y1="height"
            :x2="0"
            :y2="0"
            :stroke="colorMap[points[0].yKey]"
            stroke-width="2"
            opacity="0.5"
        />

        <line
            v-for="point in points"
            :x1="xScale(point.x)"
            :y1="0"
            :x2="xScale(point.x)"
            :y2="height"
            stroke="rgba(0,0,0,0.05)"
            stroke-width="1"
        />

        <line
            v-for="point in points"
            :x1="0"
            :y1="yScale(point.y)"
            :x2="width"
            :y2="yScale(point.y)"
            stroke="rgba(0,0,0,0.05)"
            stroke-width="1"
        />

        <line
            v-for="point in points"
            :x1="xScale(point.x)"
            :y1="yScale(point.y)"
            :x2="xScale(point.x)"
            :y2="height"
            :stroke="colorMap[point.xKey]"
            stroke-width="1"
            opacity="0.2"
        />

        <line
            v-for="point in points"
            :x1="0"
            :y1="yScale(point.y)"
            :x2="xScale(point.x)"
            :y2="yScale(point.y)"
            :stroke="colorMap[point.yKey]"
            stroke-width="1"
            opacity="0.2"
        />

        <circle
            :cx="xScale(value[points[0].xKey])"
            :cy="height"
            r="5"
            :fill="colorMap[points[0].xKey]"
        />

        <circle
            :cx="0"
            :cy="yScale(value[points[0].yKey])"
            r="5"
            :fill="colorMap[points[0].yKey]"
        />

        <circle
            :cx="xScale(value[points[0].xKey])"
            :cy="yScale(value[points[0].yKey])"
            r="5"
            fill="rgba(0,0,0,0.5)"
            opacity="0.2"
        />

    </svg>

</template>

<script>

    import * as d3 from 'd3'

    export default {
        props: {
            points: { default: [] }
        },
        data: () => ({
            height: 200,
            width: 200,
            padding: 0,
            colorMap: {
                a: 'blue',
                b: 'orange',
                c: 'red'
            },
            value: {}
        }),
        methods: {
            xScale(value) {
                return d3.scaleLinear()
                    .domain([0, 1])
                    .range([this.padding, this.width - this.padding])
                    (value)
            },
            yScale(value) {
                return d3.scaleLinear()
                    .domain([0, 1])
                    .range([this.height - this.padding, this.padding])
                    (value)
            }
        },
        mounted() {
            this.$events.$on('value', value => {
                this.value = value
            })
        }
    }

</script>

<style>
</style>
