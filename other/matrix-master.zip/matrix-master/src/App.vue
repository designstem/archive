<template>

    <div id="app">
    <input type="range" v-model="pow" min="1" max="5" step="1"> {{ pow }}
    <!--div>x: {{ xProbe }} y: {{ yProbe }}</div-->
    <div style="display: flex">
        <div style="margin-right: 2em">
            <div>
            <sample :points="filter('a', 'c')"></sample>
            <sample :points="filter('b', 'c')"></sample>
            <sample :points="filter('c', 'c')"></sample>
            </div>
            <div>
            <sample :points="filter('a', 'b')"></sample>
            <sample :points="filter('b', 'b')"></sample>
            <sample :points="filter('c', 'b')"></sample>
            </div>
            <div>
            <sample :points="filter('a', 'a')"></sample>
            <sample :points="filter('b', 'a')"></sample>
            <sample :points="filter('c', 'a')"></sample>
            </div>
        </div>
        
    </div>
    </div>

</template>

<script>

    import anime from 'animejs'
    import Sample from './components/Sample.vue'

    export default {
        name: 'App',
        components: { Sample },
        data: () => ({ pow: 1, xProbe: '', yProbe: '', x: 0 }),
        computed: {
            points() {
                var points = []
                for (var i = 0.1; i < 1; i = i + 0.1) {
                    points.push(this.calculate(i))
                }
                return points
            }
        },
        methods: {
            calculate(i) {
                return {
                    a: i,
                    b: Math.pow(i, this.pow),
                    c: Math.pow(i, 1 / this.pow)
                }
            },
            filter(x, y) {
                return this.points.map(point => {
                    return {
                        x: point[x],
                        y: point[y],
                        xKey: x,
                        yKey: y
                    }
                })
            }
        },
        watch: {
            x(value) {
                this.$events.$emit('value', this.calculate(value))
            }
        },
        mounted() {
            this.$events.$on('point', point => {
                this.xProbe = point.x ? point.x : ''
                this.yProbe = point.y ? point.y : ''
            })
            anime({
                targets: this,
                x: 1,
                duration: 2000,
                loop: true,
                easing: 'linear',
                direction: 'alternate'
            })


        }

    }

</script>

<style>

    body {
        font-family: sans-serif;
        margin: 0;
        padding: 2rem;
    }

</style>
