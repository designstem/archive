<template>
    
    <div>
        {{ value }}
    </div>

</template>

<script>

    export default {
        props: {
            value: { default: 0 }
        },
        data: () => ({})
    }

</script>

<style>
</style>
