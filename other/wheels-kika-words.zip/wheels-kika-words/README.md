### Installation

``` bash
git clone kristjanjansen/wheels
cd wheels
yarn
npm run dev
```
### Production

```bash
npm install -g now
now
```
