<template>
    
    <!--g :ref="data.name" :transform="'translate('+data.x+','+data.y+')'"-->
    <g>
        <rect :ref="data.name" :x="data.x - 10" :y="data.y - 10" width="20" height="20"/>
        <text font-size="10" :x="data.x - 10" :y="data.y + 30">x:{{ data.x }} y:{{ data.y }}</text>
    </g>
    <!--/g-->

</template>

<script>

    export default {
        props: {
            data: { default: {} }
        },
        data: () => ({}),
        mounted() {
            var coords = this
                .$refs[this.data.name]
                .getBoundingClientRect()
            console.log('node', coords)
        }
    }

</script>

<style>
</style>
