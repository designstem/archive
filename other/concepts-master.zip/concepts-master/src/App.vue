<template>

    <div id="app">
        <input type="range" v-model="width" max="1000" style="display: block">
        <svg ref="svg" :width="width" :height="width" style="background: #eee"
        @mousemove="onMove"
        >
            
            <node
                v-for="node in nodes"
                :data="node"
            >
            </node>

            <node
                :data="{x, y}"
            >
            </node>

        </svg>

    </div>

</template>

<script>

    import Node from './components/Node.vue'

    export default {
        name: 'App',
        components: { Node },
        data: () => ({
            width: 500,
            nodes: [],
            x: 0,
            y: 0
        }),
        methods: {
            onMove(e) {
                var coords = this.$refs.svg
                    .getBoundingClientRect()
                this.x = e.pageX - coords.left
                this.y = e.pageY - coords.top
            }
        },
        mounted() {
            this.nodes = [
                {name: 'Mimicry', x: 100, y: 100},
                {name: 'Materials', x: 30, y: 400}
            ]

            var coords = this.$refs.svg
                .getBoundingClientRect()
            console.log('svg', coords)
        }
    }

</script>

<style>

    body {
        font-family: sans-serif;
        margin: 0;
        padding: 2rem;
    }

</style>
