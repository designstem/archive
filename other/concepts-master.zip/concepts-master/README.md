### Installation

``` bash
git clone kristjanjansen/concepts
cd concepts
yarn
npm run dev
```
### Production

```bash
npm install -g now
now
```
